HW3
name: Lyon Kee
email: keel@oregonstate.edu

Language: c++
Running command: make
(optional) Notes: you might have to make clean and make again if it was already compiled, or simply ./(file) to run that output file. Sometimes, when you run and the computer is busy, an error of "collect2: fatal error: vfork: Resource temporarily unavailable" will occur, by doing ./(file) after making it will allow it to run, I would sometimes get this error and sometimes not, but simply copying the line that is executed and executing it will run.

!!!IMPORTANT!!!
The files might have a datatype loss at compression for example, data.txt -> data without .txt extension. Please change the file back to satisfy the assertion, and please do not mark me down like HW1 :c i am sad...


additional notes:

On teach, submission date was not changed so it is late

You can change the data set generation range by changing the starting n, steps, and ending step by changing the constants at the begining of the knapsack.cpp in line 8-11 given by N_START, N_STEP, AND N_END respectively.

to run all tests:
make clean && make

to run knapsack:
make knapsack

to run shopping:
make shopping

to clean directory of unnecessary files:
make clean


Extras:
Time calculations were gotten from chrono high resolution clock.
