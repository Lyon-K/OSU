HW7
name: Lyon Kee
email: keel@oregonstate.edu

Language: c++
Running command: make
(optional) Notes: you might have to make clean and make again if it was already compiled, or simply ./(file) <file> to run that output file. Sometimes, when you run and the computer is busy, an error of "collect2: fatal error: vfork: Resource temporarily unavailable" will occur, by doing ./(file) after making it will allow it to run, or simply copying the line that is executed and executing it will run.

!!!IMPORTANT!!!
The files might have a datatype loss at compression for example, data.txt -> data without .txt extension. Please change the file back to satisfy the assertion, and please do not mark me down like HW1 :c i am sad...


additional notes:
	to run all tests:
	make clean && make

	to clean directory of unnecessary files:
	make clean