import numpy
from matplotlib import pyplot as plt
import scipy.stats

PACKET_SERVICE_TIME_MEAN = 1
PACKET_INTER_ARRIVAL_TIME_MEAN = 0.5

numberOfPackets = 10
simulationsRange = numpy.arange(100, 1001, 10)

W_bar_results = []
W_bar_CI = []
Z_bar_results = []
Z_bar_CI = []
H_bar_results = []
H_bar_CI = []
L_bar_results = []
L_bar_CI = []
E_of_Y = numberOfPackets * PACKET_SERVICE_TIME_MEAN
E_of_Q = numberOfPackets * PACKET_SERVICE_TIME_MEAN - (numberOfPackets - 1) * PACKET_INTER_ARRIVAL_TIME_MEAN
for numberOfSimulations in simulationsRange:
    W_i_results = []
    packet_service_times_averages = []
    packet_iat_packet_service_difference_averages = []
    L_i_results = []
    for i in range(numberOfSimulations):

        packet_service_times = numpy.random.exponential(PACKET_SERVICE_TIME_MEAN, 10)
        packet_service_times_averages.append(numpy.sum(packet_service_times))
        packet_inter_arrival_times = numpy.random.exponential(PACKET_INTER_ARRIVAL_TIME_MEAN, 9)
        packet_iat_packet_service_difference_averages.append(numpy.sum(packet_service_times) - numpy.sum(packet_inter_arrival_times))
        packet_times_in_network = [packet_service_times[0]]
        packet_leaving_times_in_network = [packet_service_times[0]]
        packets_in_network = [1]

        # Q 1a
        for i in range(1, numberOfPackets):
            # packet queueing time = max(0, packet_times_in_network[i - 1] - packet_inter_arrival_times[i-1])
            packet_times_in_network.append(packet_service_times[i] + max(0, packet_times_in_network[i - 1] - packet_inter_arrival_times[i-1]))
            packet_leaving_times_in_network.append(packet_inter_arrival_times[i - 1] + packet_service_times[i] + max(0, packet_times_in_network[i - 1] - packet_inter_arrival_times[i-1]))
        W_i_results.append(numpy.sum(packet_times_in_network))

        # Q 1d
        for i in range(1, numberOfPackets):
            if sum(packet_inter_arrival_times[:i]) < packet_leaving_times_in_network[0]:
                packets_in_network.append(i + 1.5)
            elif sum(packet_inter_arrival_times[:i]) < packet_leaving_times_in_network[1]:
                packets_in_network.append(i-1 + 1.5)
            elif sum(packet_inter_arrival_times[:i]) < packet_leaving_times_in_network[2]:
                packets_in_network.append(i-2 + 1.5)
            elif sum(packet_inter_arrival_times[:i]) < packet_leaving_times_in_network[3]:
                packets_in_network.append(i-3 + 1.5)
            elif sum(packet_inter_arrival_times[:i]) < packet_leaving_times_in_network[4]:
                packets_in_network.append(i-4 + 1.5)
            elif sum(packet_inter_arrival_times[:i]) < packet_leaving_times_in_network[5]:
                packets_in_network.append(i-5 + 1.5)
            elif sum(packet_inter_arrival_times[:i]) < packet_leaving_times_in_network[6]:
                packets_in_network.append(i-6 + 1.5)
            elif sum(packet_inter_arrival_times[:i]) < packet_leaving_times_in_network[7]:
                packets_in_network.append(i-7 + 1.5)
            elif sum(packet_inter_arrival_times[:i]) < packet_leaving_times_in_network[8]:
                packets_in_network.append(i-8 + 1.5)
            elif sum(packet_inter_arrival_times[:i]) < packet_leaving_times_in_network[9]:
                packets_in_network.append(i-9 + 1.5)
            else:
                packets_in_network.append(1 + 1.5)
        # print(f"packet_times_in_network = {packet_times_in_network}")
        # print(f"packet_inter_arrival_times = {packet_inter_arrival_times}")
        # print(f"packet_leaving_times_in_network = {packet_leaving_times_in_network}")
        # print(f"packets_in_network = {packets_in_network}\n")
        L_i_results.append(numpy.sum(packets_in_network))

    # Q 1a
    curr_W_bar = numpy.average(W_i_results)
    W_bar_results.append(curr_W_bar)

    # Q 1b
    Z_bar_results.append(curr_W_bar + (-numpy.cov(W_i_results, packet_service_times_averages)[0][1]/numpy.var(packet_service_times_averages)) * (numpy.average(packet_service_times_averages) - E_of_Y))
    
    # Q 1c
    H_bar_results.append(curr_W_bar + (-numpy.cov(W_i_results, packet_iat_packet_service_difference_averages)[0][1]/numpy.var(packet_iat_packet_service_difference_averages)) * (numpy.average(packet_iat_packet_service_difference_averages) - E_of_Q))

    # Q 1d
    L_bar_results.append(numpy.average(L_i_results) * 1.0)

    # normalized 90% CI plot
    W_bar_sem = scipy.stats.sem(W_bar_results)
    W_bar_CI.append(W_bar_sem * scipy.stats.t.ppf((1 + 0.9) / 2.0, numberOfSimulations-1))
    
    Z_bar_sem = scipy.stats.sem(Z_bar_results)
    Z_bar_CI.append(Z_bar_sem * scipy.stats.t.ppf((1 + 0.9) / 2.0, numberOfSimulations-1))
    
    H_bar_sem = scipy.stats.sem(H_bar_results)
    H_bar_CI.append(H_bar_sem * scipy.stats.t.ppf((1 + 0.9) / 2.0, numberOfSimulations-1))
    
    L_bar_sem = scipy.stats.sem(L_bar_results)
    L_bar_CI.append(L_bar_sem * scipy.stats.t.ppf((1 + 0.9) / 2.0, numberOfSimulations-1))

print("Min Simulations for 90% CI of W_bar", simulationsRange[next((i for i, x in enumerate(W_bar_CI) if x < 0.2), -1)])
print("Min Simulations for 90% CI of Z_bar", simulationsRange[next((i for i, x in enumerate(Z_bar_CI) if x < 0.2), -1)])
print("Min Simulations for 90% CI of H_bar", simulationsRange[next((i for i, x in enumerate(H_bar_CI) if x < 0.2), -1)])
print("Min Simulations for 90% CI of L_bar", simulationsRange[next((i for i, x in enumerate(L_bar_CI) if x < 0.2), -1)])

plt.subplot(1, 2, 1)
plt.plot(simulationsRange, W_bar_results, label = "W_BAR")
plt.plot(simulationsRange, Z_bar_results, label = "Z_BAR")
plt.plot(simulationsRange, H_bar_results, label = "H_BAR")
plt.plot(simulationsRange, L_bar_results, label = "L_BAR")
plt.title("Estimated Theta vs Number of Simulations Ran")
plt.xlabel('Number of Simulation runs, n')
plt.ylabel('Packet Time Spent in Access Point')
plt.legend()
# NORMALIZED
plt.subplot(1, 2, 2)
plt.plot(simulationsRange, W_bar_CI, label = "W_BAR")
plt.plot(simulationsRange, Z_bar_CI, label = "Z_BAR")
plt.plot(simulationsRange, H_bar_CI, label = "H_BAR")
plt.plot(simulationsRange, L_bar_CI, label = "L_BAR")
plt.title("Normalized 90% confidence interval width")
plt.xlabel('Number of Simulation runs, n')
plt.ylabel('90% CI Packet Time Spent in Access Point')
plt.legend()
# Show plots
plt.show()