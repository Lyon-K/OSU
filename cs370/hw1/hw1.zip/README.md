Running on Python 3.10.12

run Q3.2 with:
python Q3.2.py
or
<your python executable> Q3.2.py
The results are printed in the terminal

run Q3.3 with:
python Q3.3.py
or
<your python executable> Q3.3.py
NOTE: The results are printed on in the terminal then saved in a file known as `Q3.3_results.txt`