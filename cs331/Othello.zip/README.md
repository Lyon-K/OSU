Fill out players.py. Look at canvas for further instructions.
You can edit run.sh for testing or create your own test file.
Original code by Erich Kramer - April 2017 - Apache license
Edited for OSU CS331 SP23